// Department filtering functionality
document.addEventListener('DOMContentLoaded', function() {
    const departmentTags = document.querySelectorAll('.tag');
    const teamCards = document.querySelectorAll('.team-card');
    
    // Add click event listeners to department tags
    departmentTags.forEach(tag => {
        tag.addEventListener('click', function() {
            const selectedDepartment = this.dataset.department;
            
            // Remove active class from all tags
            departmentTags.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tag
            this.classList.add('active');
            
            // Filter team cards
            filterTeamCards(selectedDepartment);
        });
    });
    
    // Function to filter team cards based on department
    function filterTeamCards(department) {
        teamCards.forEach(card => {
            if (department === 'todos') {
                // Show all cards
                card.classList.remove('hidden');
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100);
            } else {
                // Check if card belongs to selected department
                const cardDepartment = card.dataset.department;
                
                if (cardDepartment === department) {
                    card.classList.remove('hidden');
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 100);
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        card.classList.add('hidden');
                    }, 300);
                }
            }
        });
    }
    
    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Add smooth scroll behavior if linking to sections
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
    
    // Add intersection observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe cards and team members for scroll animations
    const animatedElements = document.querySelectorAll('.card, .team-card');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
    
    // Add hover effects to cards
    const cards = document.querySelectorAll('.card, .team-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(-4px)';
        });
    });
    
    // Mobile menu functionality (if needed in future)
    const handleResize = () => {
        const isMobile = window.innerWidth < 768;
        
        if (isMobile) {
            // Adjust grid layout for mobile
            const teamGrid = document.querySelector('.team-grid');
            if (teamGrid) {
                teamGrid.style.gridTemplateColumns = '1fr';
            }
        }
    };
    
    // Listen for window resize
    window.addEventListener('resize', handleResize);
    
    // Initial call
    handleResize();
    
    // Add loading animation
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.5s ease';
    
    window.addEventListener('load', function() {
        document.body.style.opacity = '1';
    });
});

// Utility function to create smooth transitions
function smoothTransition(element, property, value, duration = 300) {
    element.style.transition = `${property} ${duration}ms ease`;
    element.style[property] = value;
}

// Function to handle dynamic content loading (future enhancement)
function loadTeamMember(memberData) {
    const teamGrid = document.querySelector('.team-grid');
    
    const memberCard = document.createElement('div');
    memberCard.className = 'team-card';
    memberCard.dataset.department = memberData.department;
    
    memberCard.innerHTML = `
        <div class="team-photo">
            <i class="fas fa-user-circle"></i>
            <span class="photo-label">${memberData.name.split(' ')[0]}</span>
        </div>
        <div class="team-info">
            <h4 class="team-name">${memberData.name}</h4>
            <p class="team-role">${memberData.role}</p>
            <span class="team-department">${memberData.departmentLabel}</span>
            <p class="team-description">${memberData.description}</p>
        </div>
    `;
    
    teamGrid.appendChild(memberCard);
    
    // Animate the new card
    memberCard.style.opacity = '0';
    memberCard.style.transform = 'translateY(30px)';
    
    setTimeout(() => {
        memberCard.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        memberCard.style.opacity = '1';
        memberCard.style.transform = 'translateY(0)';
    }, 100);
}

// Export functions for potential future use
window.TeamApp = {
    filterTeamCards: function(department) {
        const departmentTags = document.querySelectorAll('.tag');
        const targetTag = document.querySelector(`[data-department="${department}"]`);
        
        if (targetTag) {
            targetTag.click();
        }
    },
    loadTeamMember: loadTeamMember
};
